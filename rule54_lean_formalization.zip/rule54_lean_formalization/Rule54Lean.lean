import Rule54Lean.RuleID
import Rule54Lean.OnlineCheckpoint
import Rule54Lean.CommonTails
import Rule54Lean.ObservedHalts
import Rule54Lean.SamplingClock
import Rule54Lean.OrdinarySampler
import Rule54Lean.InfiniteOrbit
import Rule54Lean.BulkCases

/-! General mathematical part of the certificate, including exact physical
composition, executable source simulation and soundness of the bulk checker.
The file Rule54WeakUniversality closes the two finite replay hypotheses. -/
#print axioms Rule54Lean.Route.physicalSweep
#print axioms Rule54Lean.U15Universal.universal_simulation
#print axioms Rule54Lean.BulkCases.bulk_sound
