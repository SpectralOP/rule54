# Weak universality of elementary Rule 54

This project formalizes a simulation of arbitrary finite-state binary Turing machines by the synchronous, one-dimensional, two-state elementary cellular automaton with Wolfram number 54. The simulated tape extends in both directions and is initially blank outside a finite interval. The CA encoding has two fixed periodic backgrounds. A computable finite region contains the program and input.

## Main theorems

The closed entry points are in `Rule54WeakUniversality.lean`, under `Rule54Lean.WeakUniversality`.

| Theorem | Conclusion |
| --- | --- |
| `simulation_iff` | For any requested ordinary step number, the source reaches a specified configuration exactly when the executable sampler returns that configuration from the physical trajectory for some finite bounds. The desired result is not supplied to the sampler. |
| `weak_universality` | For any finite source run, elementary Rule 54 reaches a time at which an executable observer recovers the final source control state and entire source tape. The observer locates both banks from the actual cells. |
| `simulated_at_clock` | Each source configuration in a finite run occurs at a member of the same input-determined, computable sequence of sampling times. |
| `infinite_run` | For an infinite source history there is one strictly increasing sequence of times along the same CA orbit that displays all of its configurations in order. |
| `halting_observation` | The source halts if and only if the executable Boolean test `haltWithin` reports true for some finite budget. Every positive report reads the halted control and scanned bit from the evolved elementary row. |

`UniversalCheckpoint.common_tails` proves pointwise agreement with the same left and right reference configurations, including their spatial phases, for every program and input. `UniversalCheckpoint.periodic_input` gives the periods. `Rule54.number_is_54` checks the update rule against the standard Wolfram neighborhood numbering.

## Reproduce

Use the pinned Lean **4.23.0** toolchain on 64-bit Linux, with `lean`, `lake`, and `leanc` available. The Python scripts use the standard library. The formalization imports Lean and its bundled standard library. From this directory run

```sh
python3 tools/verify.py --jobs 2
```

The script compiles the mathematical development, verifies the two native decisions, and compiles the closed theorems. On a memory-constrained system use `--jobs 1`. The proof compilation increases the Lean worker stack size for the larger concrete fixtures. Generated objects are placed in `.verify` and `.lake`. These directories are omitted from the archive so the first run checks the supplied sources. The axiom audit is printed when the closed theorem module is compiled.

To run the finite checker independently, use

```sh
lake build bulkReplay
.lake/build/bin/bulkReplay BulkData
```

The complete replay checks 1,301,192 shared nodes and 28,314 pairs of root windows. Of these cases 11,240 concern transport and 17,074 concern the writers. Separate proofs cover stationary patterns, free propagation and all required subtractors. `BulkCases.cover` proves that together they cover both finite manifests. The input and output of each fixture are complete configurations on the integer line. `Arena`, `Bulk`, and `BulkCases` prove why acceptance by the finite checker entails those infinite-row equalities.

The witness database is included. Its SHA-256 digests are

```text
cc44236c4f98956b31d225bfad425819e1ef956f5d85ea646b8db4a59d4c42bd  BulkData/nodes.txt
1346459e6f6ca075b3a83ed1198b1ecdfc7397ecb0305ba87048a9bb4831e48d  BulkData/roots.txt
```

`python3 tools/make_arena.py regenerated` regenerates the two files from the three included upstream C++ sources with a C++17 compiler. The Lean checker verifies the structural dependencies and actual boundary words independently of the program that generated them.

## What the simulation proves

1. `Block.tick_group` identifies an update on groups of four cells with four synchronous elementary Rule 54 updates. `Coordinates` proves that grouping and ungrouping preserve the whole configuration on the integer lattice.
2. `Route.physicalSweep` and `Checkpoint.sample_exact` join actual signal flights and collisions on one evolving row. The proofs cover the contents of each station, the clearance of every intervening slot, the direction of flight, both write branches, and return to the next read. The proof iterates for every finite number of queue operations. The exact elementary clock is `Checkpoint.clockAt`.
3. `Tag`, `Weighted`, and `Compiler` implement the binary Turing tape by a deletion-two tag system and a fixed 396-phase cyclic queue. The initial tag word chooses the permitted placement of the adjacent guard pair between the left and right counter fields. The two guard symbols and the padding maintain the required invariants for an unbounded run.
4. `U15Universal.sim` and `U15Universal.universal_simulation` prove the fixed 15-state, two-symbol machine simulates arbitrary ordinary binary machines. The published transition table is a definition in Lean. Its universality is proved inside this project. `U15Read.read_compile` proves that the compiled state and tape decode back to the original source state and tape.
5. `ObservedMachine`, `ObservedHalts`, and `InfiniteOrbit` give the elementary-cell observations used in the final theorems. `OnlineCheckpoint.nextCut_correct` also verifies how to advance the physical clock from the current physical row, the bank cursors, and the cyclic phase. Its `watch_exact` theorem iterates that observation through any finite number of phases. Reading halting is a synchronized observation of the simulated machine. The CA itself keeps evolving.

The time-zero row is computed from the machine and input alone. Neither the computation history nor its length is an argument to the encoder. The first common physical checkpoint occurs after 33,816,516 elementary updates. The construction uses periodic tails and makes no efficiency claim.

## Trust and sources

There are no project axioms or admitted proof terms. The mathematical composition and the proof of soundness of the finite checker use standard Lean proof terms. Two uses of `native_decide` in `Rule54Native.lean` evaluate the concrete, large collision database with the Lean compiler. For the closed theorem, `#print axioms` reports `propext`, `Classical.choice`, `Quot.sound`, `Lean.ofReduceBool` and `Lean.trustCompiler`. The last two identify the additional trust in native evaluation. No C++ simulation result is introduced as an axiom.

The finite-state transition table comes from Turlough Neary and Damien Woods, “Four Small Universal Turing Machines,” *Fundamenta Informaticae* 91 (2009), 105–126, [doi:10.3233/FI-2009-0036](https://doi.org/10.3233/FI-2009-0036). The tag-system approach draws on Matthew Cook, “A Concrete View of Rule 110 Computation” (2009), [arXiv:0906.3248](https://arxiv.org/abs/0906.3248). The construction verified here uses Rule 54.
