import Rule54Data
namespace Rule54Lean.NativeReplay
open Rule54.Arena BulkCases NativeData
private theorem db_ok : nodeTest=true := by native_decide
private theorem cases_ok : caseTest=true := by native_decide
theorem all_collisions : Manifest.TransportValid ∧ Manifest.WritersValid :=
  bulk_sound db roots db_ok cases_ok
#print axioms all_collisions
end Rule54Lean.NativeReplay
