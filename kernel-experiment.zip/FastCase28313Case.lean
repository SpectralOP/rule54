import FastCase28313Data
namespace Rule54Lean.FastCase28313
open Rule54.KernelArena Rule54.KernelBulk
set_option maxHeartbeats 5000000
set_option maxRecDepth 200000
theorem case_ok : testCase db witness fixture = true := by
  simp [fixture, Manifest.writer, Manifest.ceilPow, Nat.log2]
  decide +kernel
#print axioms case_ok
end Rule54Lean.FastCase28313
