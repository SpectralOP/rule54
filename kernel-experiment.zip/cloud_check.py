"""Run one kernel-only certificate experiment; never suppress a failed proof."""
from pathlib import Path
import subprocess,os,sys,time,json

root=Path(__file__).resolve().parent
logs=root/'cloud-logs'; logs.mkdir(exist_ok=True)
env=dict(os.environ,LEAN_PATH=str(root/'.verify'))
case=sys.argv[1]
def run(name,args):
    print('Running',name,flush=True)
    start=time.monotonic()
    result=subprocess.run(args,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=1800)
    (logs/(name+'.log')).write_text(result.stdout,encoding='utf-8')
    print(result.stdout,flush=True)
    print('Elapsed seconds',round(time.monotonic()-start,2),flush=True)
    if result.returncode: raise SystemExit(result.returncode)
    # Lean can print an axiom report after a failed declaration. Both the exit
    # status above and every reported proof dependency have to pass.
    forbidden=['sorryAx','Lean.ofReduceBool','Lean.ofReduceNat','Lean.trustCompiler','declaration uses']
    if any(word in result.stdout for word in forbidden):
        raise SystemExit('Forbidden proof dependency or admitted declaration')

run('generic-arena',['lean','-j1','-s','262144','-o','.verify/KernelArena.olean','KernelArena.lean'])
run('generic-bulk',['lean','-j1','-s','262144','-o','.verify/KernelBulk.olean','KernelBulk.lean'])
if case=='small':
    run('small-closed-collision',['lean','-j1','-s','262144','-o','.verify/Rule54FastProbe.olean','Rule54FastProbe.lean'])
else:
    label='FastCase'+case
    run(label+'-data',['lean','-j1','-s','262144','-o','.verify/'+label+'Data.olean',label+'Data.lean'])
    run(label+'-nodes',['lean','-j1','-s','262144','-o','.verify/'+label+'Nodes.olean',label+'Nodes.lean'])
    run(label+'-case',['lean','-j1','-s','262144','-o','.verify/'+label+'Case.olean',label+'Case.lean'])
    # Close the actual collision theorem, not just the Boolean checks.
    source=f'''import {label}Nodes
import {label}Case
namespace Rule54Lean.{label}
open Rule54.KernelBulk
theorem collision : fixture.Valid := testCase_sound db_ok case_ok
#print axioms collision
end Rule54Lean.{label}
'''
    path=root/(label+'Closed.lean'); path.write_text(source,encoding='utf-8')
    run(label+'-closed',['lean','-j1','-s','262144',str(path)])
print('KERNEL-ONLY EXPERIMENT PASSED. This is a sample, not the full universality theorem.',flush=True)
