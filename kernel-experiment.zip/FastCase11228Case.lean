import FastCase11228Data
namespace Rule54Lean.FastCase11228
open Rule54.KernelArena Rule54.KernelBulk
set_option maxHeartbeats 5000000
set_option maxRecDepth 200000
theorem case_ok : testCase db witness fixture = true := by decide +kernel
#print axioms case_ok
end Rule54Lean.FastCase11228
