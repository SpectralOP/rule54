"""Event-order schematic for the first, intermediate zero writer at q=1241."""
from pathlib import Path
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

mpl.rcParams.update({"font.family": "DejaVu Sans", "font.size":8, "pdf.fonttype":42})
ink="#20333b"; accent="#075663"; line="#879097"
fig,ax=plt.subplots(figsize=(6.1,2.65))
fig.subplots_adjust(left=.015,right=.997,top=.99,bottom=.02)
ax.set_xlim(-.47,4.8);ax.set_ylim(6.1,-.75);ax.axis("off")
names=["Terminal","Zero candidate","Older record","Receiver"]
for j,s in enumerate(names):
 ax.plot([j,j],[-.06,5.65],color=line,lw=.65,ls=(0,(2,3)),zorder=0)
 ax.text(j,-.3,s,ha="center",va="center",weight="bold",size=7.6,color=ink)
path=[(1.66,.3),(1,1),(0,2),(1,3),(2,4),(3,5),(2.36,5.65)]
for (a,b),(c,d) in zip(path,path[1:]):
 ax.add_patch(FancyArrowPatch((a,b),(c,d),arrowstyle='-|>',connectionstyle="arc3",mutation_scale=8,shrinkA=1,shrinkB=1.4,lw=1.2,color=accent))
for x,y in path[1:-1]:
 ax.scatter(x,y,s=14,marker="o",color=ink,zorder=3)
labels=[
 (1.75,.32,"$B_1$ or $B_9$ after subtraction"),
 (1.13,1.05,"Prefix spent, exposing $T_2$"),
 (.12,1.94,"Terminal consumed"),
 (1.12,2.93,"Erase or retain $T_2$"),
 (2.12,3.97,"$E_{15}$ or $E_6$ after this crossing"),
 (3.1,5.02,"Receiver consumed"),
]
for x,y,s in labels: ax.text(x,y,s,ha='left',va='center',size=7.3,color=ink,bbox=dict(facecolor="white",edgecolor="none",pad=.6))
ax.text(2.19,5.83,"Westward return",ha="center",size=7.3,color=ink)
ax.annotate("",xy=(-.35,5.5),xytext=(-.35,.2),arrowprops=dict(arrowstyle="->",lw=.8,color=ink))
ax.text(-.42,2.7,"Event order",rotation=90,va='center',ha='center',size=7,color=ink,bbox=dict(facecolor='white',edgecolor='none',pad=.4))
fig.savefig(Path(__file__).resolve().with_suffix(".pdf"),bbox_inches="tight",pad_inches=.03)
