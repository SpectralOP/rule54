"""Reproduce fig_collision.pdf (Python 3, NumPy, Matplotlib).

An independent elementary-rule computation of Manifest.subtractFixture 3 4.
A 1,024-cell ring suffices: every possible change through time 128 is
strictly inside it, so no altered light cone reaches the periodic seam.
"""
from pathlib import Path

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
import numpy as np

ETHER = 13
FIRST_GROUP = -96
GROUP_COUNT = 256
SUB = "c7c3f77777ef"
LENGTH = 128
PLOT_LEFT = -16
PLOT_RIGHT = 184


def packet(amplitude):
    return "ddd".join(["11d11"] * amplitude)


def insert(row, group, text):
    offset = group - FIRST_GROUP
    row[offset:offset + len(text)] = [int(d, 16) for d in text]


def elementary(row):
    left, right = np.roll(row, 1), np.roll(row, -1)
    return row ^ (left | right)


def blocked(row):
    """Four-step nibble lookup, independent of elementary() below."""
    word = (np.roll(row, 1) << 8) | (row << 4) | np.roll(row, -1)
    for _ in range(4):
        word = (word >> 1) ^ ((word >> 2) | word)
    return word & 15


def vertices(mask, xstart, xwidth, ystep):
    """Merge runs along each row. Use true polygons for a vector PDF."""
    rectangles = []
    for yi, line in enumerate(mask):
        edges = np.flatnonzero(np.diff(np.r_[0, line, 0]))
        for i, j in edges.reshape(-1, 2):
            x0, x1 = xstart + i*xwidth, xstart + j*xwidth
            y0, y1 = yi*ystep-0.5*ystep, yi*ystep+0.5*ystep
            rectangles.append([(x0, y0), (x1, y0), (x1, y1), (x0, y1)])
    return rectangles


def spacetime():
    init = np.full(GROUP_COUNT, ETHER, dtype=np.uint16)
    insert(init, 0, SUB)
    insert(init, 14, packet(4))
    expected = np.full_like(init, ETHER)
    insert(expected, 6, packet(1))
    shifts = np.array([3, 2, 1, 0])
    raw = ((init[:, None] >> shifts) & 1).ravel()
    rows = [raw]
    blocks = [init]
    for t in range(1, LENGTH + 1):
        raw = elementary(raw)
        rows.append(raw)
        if t % 4 == 0:
            blocks.append(blocked(blocks[-1]))
            direct = (raw.reshape(-1, 4) @ (1 << shifts)).astype(np.uint16)
            assert np.array_equal(direct, blocks[-1])
    assert np.array_equal(blocks[-1], expected)
    assert FIRST_GROUP*4 < -LENGTH
    assert 4*(14+len(packet(4))) + LENGTH < 4*(FIRST_GROUP+GROUP_COUNT)
    return np.array(rows), np.array(blocks)


def draw(path):
    raw, blocks = spacetime()
    mpl.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5,
                         "axes.linewidth": .55, "xtick.major.width": .55,
                         "ytick.major.width": .55, "pdf.fonttype": 42})
    fig, axes = plt.subplots(1, 2, figsize=(5.8, 2.85))
    fig.subplots_adjust(left=.095, right=.986, bottom=.23, top=.84, wspace=.20)
    for i, ax in enumerate(axes):
        if i == 0:
            line = raw[:, PLOT_LEFT-4*FIRST_GROUP:PLOT_RIGHT-4*FIRST_GROUP]
            rects = vertices(line, PLOT_LEFT, 1, 1)
            ax.set_ylim(128.5, -.5)
        else:
            line = blocks[:, PLOT_LEFT//4-FIRST_GROUP:PLOT_RIGHT//4-FIRST_GROUP] != ETHER
            rects = vertices(line, PLOT_LEFT, 4, 4)
            ax.set_ylim(130, -2)
        ax.add_collection(PolyCollection(rects, facecolors="#171717", edgecolors="none",
                                          antialiaseds=False))
        ax.set_xlim(PLOT_LEFT, PLOT_RIGHT)
        ax.set_xticks([0, 40, 80, 120, 160])
        ax.set_yticks([0, 32, 64, 96, 128])
        ax.tick_params(axis="both", direction="out", length=2.2, pad=2.5, labelsize=7.5)
        ax.set_xlabel("Elementary cell $x$", labelpad=4)
        ax.set_title(["(a)  Elementary states", "(b)  Departures from the ether"][i],
                     loc="left", fontsize=9.0, pad=7)
    axes[0].set_ylabel("Elementary time $t$", labelpad=3)
    axes[1].tick_params(labelleft=False)
    fig.savefig(path, metadata={"Title": "A subtractor collision in elementary Rule 54",
                                "Creator": "fig_collision.py"})
    plt.close(fig)


if __name__ == "__main__":
    draw(Path(__file__).resolve().with_suffix(".pdf"))
