# Weak Turing universality of elementary cellular automaton Rule 54

The manuscript proves weak Turing universality for the synchronous elementary rule on the integer line. Its initial rows have two common, fixed-phase periodic tails. The source machine and its input occupy a computable finite region. The main result recovers the control state and full two-sided source tape at synchronized times.

## Read or typeset the paper

Open Rule_54_Weak_Universality_Paper.pdf in this directory. Manuscript/manuscript.tex is the editable entry point. All included section files and both vector figures are beside it. With a standard TeX Live installation, run the following from this directory.

```sh
cd Manuscript
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
```

The figure sources are optional. Python 3, NumPy, and Matplotlib reproduce the first figure. Matplotlib reproduces the second. Each script writes its figure beside the script.

```sh
python3 fig_collision.py
python3 fig_writer.py
```

The first script evolves both the elementary cells and the four-step grouped rule and checks their agreement at the sampled times. The second figure is a schematic of the event order in the worked example.

## Verify the theorem

The unmodified Lean source archive, Proof/rule54_lean_formalization.zip, has SHA-256 digest

```text
fd9f9788f83e44eed7aeaeeb96def5b605c2b98e2eba6e641b4618cd1fea3ef4
```

Starting again from the directory containing this README, use the pinned Lean 4.23.0 toolchain on 64-bit Linux. The verification script expects lean, lake, and leanc on the executable search path. It also uses Python 3. To build from the supplied sources and print the theorem audit, run

```sh
cd Proof
unzip -q rule54_lean_formalization.zip
cd rule54_lean_formalization
python3 tools/verify.py --jobs 2
```

The complete proof entry point is Rule54WeakUniversality.lean. The theorem simulation_iff gives exact finite-step readout. The theorems infinite_run and halting_observation give ordered infinite runs and the equivalence for halting. The two uses of native_decide in Rule54Native.lean accept finite certificate data. Their soundness for the semantics on the infinite integer line is proved in the project. VERIFICATION.txt records the theorem dependencies. BulkData/nodes.txt and BulkData/roots.txt contain the finite witnesses. A fresh successful build can be inspected in Proof/verification-log.txt.

The original archive's README uses an alternate page range for Neary and Woods. The manuscript bibliography follows the journal pagination, 123–144. The online queue clock theorem is Checkpoint.watch_exact in Rule54Lean/OnlineCheckpoint.lean.

To regenerate the collision data with a C++17 compiler and compare them byte for byte, start in the unpacked formalization directory and run

```sh
python3 tools/make_arena.py regenerated
cmp BulkData/nodes.txt regenerated/nodes.txt
cmp BulkData/roots.txt regenerated/roots.txt
```

## Check the size of the spatial period

Starting from the directory containing this README, after unpacking and verifying the Lean project above, run

```sh
python3 Ancillary/count_period.py Proof/rule54_lean_formalization
cd Proof/rule54_lean_formalization
LEAN_PATH=".verify:.lake/build/lib/lean" lean -s 262144 ../../Ancillary/PeriodCount.lean
```

Both computations give 56,897,671 stations for one complete left program cycle. The elementary spatial period is 3,818,338,065,055,744. PeriodCount.lean contains an additional, independent native decision for this numerical count. The count is ancillary to the universality theorem.
