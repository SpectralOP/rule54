import Rule54Lean.Stations

namespace PeriodCount
open Rule54Lean
def count (d l : Nat) : List Bool → Nat
  | [] => 0
  | b :: bs =>
    let h := if bs.isEmpty then 2 else 6
    let d' := d + Native.weight b
    (l-Native.base b)/3 + 2 + count d' (1241-h-d') bs

theorem charge_length (n : Nat) : (Stations.charges n).length = n/3 := by
  unfold Stations.charges
  split
  · simp; omega
  · simp; omega

theorem length_eq (bs : List Bool) (d l : Nat) :
    (Stations.stations d l bs).length = count d l bs := by
  induction bs generalizing d l with
  | nil => rfl
  | cons b bs ih => simp [Stations.stations,count,ih,charge_length]; omega

def period : Nat := ((List.range 396).map (fun p => count 8 1242 (Stations.phaseWord p))).sum

theorem cycle_length : Stations.cycle.length = period := by
  unfold Stations.cycle period
  rw [List.length_flatMap]
  simp [length_eq]

theorem exact_count : Stations.cycle.length = 56897671 := by
  rw [cycle_length]
  native_decide

#eval period

end PeriodCount
