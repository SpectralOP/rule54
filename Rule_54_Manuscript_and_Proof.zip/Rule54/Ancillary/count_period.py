"""Count the 396-phase left station bank without expanding physical stations.

Usage: python3 count_period.py path/to/rule54_lean_formalization
Reads the transition-table literals in Rule54Lean/SourceMachine.lean.
"""
from pathlib import Path
import re
import sys

def productions(path):
    source = (path / "Rule54Lean" / "SourceMachine.lean").read_text()
    tables = []
    for name in ("blankTable", "markTable"):
        raw = re.search(r"private def " + name + r"\b[^#]*#\[([^\]]+)\]", source)
        tables.append([entry.strip() for entry in raw.group(1).split(",")])
    out = [[0, 0]]                   # G -> GG
    for state in range(15):
        head = 1 + 10 * state
        for kind in range(3):        # uncolored H,L,R -> colors 1,0
            out.append([head + 7 + kind, head + 4 + kind])
        out.append([head + 2] * 2)   # J -> RR
        for bit in (0, 1):
            entry = tables[bit][state]
            if entry == "none":
                out.extend((([head + 8] if bit else []), [], []))
                continue
            instr, number = entry.split()
            target = 1 + 10 * int(number)
            twice = 2 * (instr[0] == "b")
            heads = [target] * (2 - bit)
            if instr[1] == "R":
                out.extend((heads + [target + 1] * twice, [target + 1] * 4,
                            [target + 2]))
            else:
                out.extend(([target + 3] * twice + heads, [target + 1],
                            [target + 2] * 4))
    assert len(out) == 151
    return out

def word(production):
    real = "".join("0" * a + "1" + "0" * (197 - a) for a in production)
    ones = 1 + 23 * (4 - len(production))
    a, b = max(0, ones - 47), min(47, ones)
    pad = "0" * (198 - a) + "1" * a + "0" * (198 - b) + "1" * b
    return real + pad

def stations(bits):
    delta, low, count = 8, 1242, 0
    for index, bit in enumerate(bits):
        debit = low - (4 if bit == "1" else 1)
        assert debit == 0 or debit >= 3
        count += debit // 3 + 2
        delta += 10 if bit == "1" else 1
        low = 1241 - (2 if index + 1 == len(bits) else 6) - delta
    assert delta == 1241 and bits.endswith("1")
    return count

if __name__ == "__main__":
    rules = productions(Path(sys.argv[1]))
    words = [word(r) for r in rules + [[]] * (396 - len(rules))]
    total = sum(map(stations, words))
    print("Stations in compiled left cycle:", total)
    print("Elementary-cell period:", 4 * 2**24 * total)
    print("Bits in all appendants:", sum(map(len, words)))
    print("Ones in all appendants:", sum(w.count("1") for w in words))
