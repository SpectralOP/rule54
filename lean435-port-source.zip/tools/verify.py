"""Fresh dependency-ordered Lean compilation, full native replay and closed theorem."""
from pathlib import Path
import argparse
import os
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--jobs", type=int, default=2, help="parallel proof elaborations")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
out = root / ".verify"
subprocess.run([sys.executable, "tools/check.py", "--jobs", str(args.jobs), "Rule54Lean"], cwd=root, check=True)
subprocess.run([sys.executable, "tools/native_check.py"], cwd=root, check=True)
env = dict(os.environ, LEAN_PATH=os.pathsep.join(map(str, [out, root / ".lake/build/lib/lean"])))
cmd = ["lean", "-j1", "-s", "262144", "-o", str(out / "Rule54WeakUniversality.olean"),
       str(root / "Rule54WeakUniversality.lean")]
subprocess.run(cmd, env=env, cwd=root, check=True)
print("Verified Rule54Lean.WeakUniversality.weak_universality", flush=True)
