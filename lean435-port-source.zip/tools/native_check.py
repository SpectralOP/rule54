"""Build the concrete collision witness and check its two native_decide proofs."""
from pathlib import Path
import os
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
objdir = root / ".lake/build/ir"
oleans = root / ".lake/build/lib/lean"
plugin_dir = root / ".lake/native-certificate"
plugin_dir.mkdir(parents=True, exist_ok=True)
mods = set()

def closure(name):
    if name in mods:
        return
    mods.add(name)
    path = root / (name.replace(".", "/") + ".lean")
    for src in re.findall(r"^import +(Rule54\w*(?:\.\w+)*)\s*$", path.read_text(), re.M):
        closure(src)

def run(cmd, **kwargs):
    subprocess.run(cmd, cwd=root, check=True, **kwargs)

closure("Rule54Data")
targets = sorted(mods)
run(["lake", "build", *["+" + m + ":c.o" for m in targets]])
objects = []
for m in targets:
    base = objdir / (m.replace(".", "/") + ".c.o")
    obj = Path(str(base) + ".export")
    objects.append(str(obj if obj.exists() else base))
lib = plugin_dir / "libRule54Data.so"
run(["leanc", "-shared", "-o", str(lib), *objects])
# Loading the compiled pure definitions keeps the full replay within a few
# minutes. The two uses of native_decide are visible in the axiom report.
run(["lean", "-j1", "-s", "262144", "--plugin=" + str(lib), "-o",
     str(oleans / "Rule54Native.olean"), str(root / "Rule54Native.lean")],
    env=dict(os.environ, LEAN_PATH=str(oleans)))
