"""Generate and kernel-check the complete Rule 54 collision certificate.

The Python generator is untrusted. Every generated certificate obligation is
proved by Lean's kernel; the original manifest and closed theorem are retained.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse, hashlib, json, math, os, re, subprocess, sys, tarfile, time, zipfile

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'.verify'
LOG=ROOT/'kernel-logs'
LOG.mkdir(exist_ok=True)
COUNT=1301192
DEPTH=21
BLOCK_DEPTH=13
LEAF_DEPTH=6
BLOCKS=1<<(DEPTH-BLOCK_DEPTH)
DB_PART=4096
FORBIDDEN=re.compile(r'\b(?:sorryAx|Lean\.ofReduceBool|Lean\.ofReduceNat|Lean\.trustCompiler)\b|declaration uses .sorry.')
EMIT_ONLY=False

def write(name,text):
    p=ROOT/name; p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding='utf-8')

def run(name,args,timeout=1800):
    start=time.monotonic()
    env=dict(os.environ,LEAN_PATH=str(OUT))
    print('BEGIN',name,flush=True)
    result=subprocess.run(args,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
    (LOG/(name.replace('/','-')+'.log')).write_text(result.stdout,encoding='utf-8')
    print(result.stdout[-12000:],flush=True)
    print('END',name,'exit',result.returncode,'seconds',round(time.monotonic()-start,2),flush=True)
    if result.returncode or FORBIDDEN.search(result.stdout):
        raise RuntimeError('Kernel check failed: '+name)
    return result.stdout

def compile_module(name):
    if EMIT_ONLY: return ''
    path=name.replace('.','/')
    dest=OUT/(path+'.olean'); dest.parent.mkdir(parents=True,exist_ok=True)
    return run(name,['lean','-j1','-s','262144','-o',str(dest),path+'.lean'])

def field(bs): return sum((c-48)<<(6*j) for j,c in enumerate(bs))

def keys():
    ks=[]; q=1241
    for n in range(1,1251):
        for k in [2,18]:
            ks.extend(f'.west {k} {n} {j}' for j in range(3))
            ks.append(f'.eastward {k} {n}')
        if 5<=n<q: ks.append(f'.passive {n}')
    ks.extend(['.active','.overflow','.head 2','.head 18'])
    for d in range(8,q):
        for h in [2,6]:
            for b in [False,True]:
                if (h==2 and b and d==q-10) or (h==6 and d+(10 if b else 1)<=q-10):
                    ks.extend(f'.writer {d} {h} {str(b).lower()} {i}' for i in range(6 if b else 8))
    assert len(ks)==28314
    return ks

def and_proof(items):
    if len(items)==1: return items[0]
    m=len(items)//2
    return 'Bool.and_eq_true_iff.mpr ⟨'+and_proof(items[:m])+', '+and_proof(items[m:])+'⟩'

def node_table(ns):
    if len(ns)<=8:
        return '.leaf ['+','.join('⟨'+','.join(map(str,n))+'⟩' for n in ns)+']'
    cut=1<<((len(ns)-1).bit_length()-1)
    return f'(.branch {cut} ({node_table(ns[:cut])}) ({node_table(ns[cut:])}))'

def part_table(items):
    if len(items)==1: return items[0][0]
    # Parts have equal capacity except the final part. Split by a power of two.
    m=1<<((len(items)-1).bit_length()-1)
    cut=sum(n for _,n in items[:m])
    return f'(.branch {cut} ({part_table(items[:m])}) ({part_table(items[m:])}))'

def prepare():
    data=(ROOT/'BulkData/nodes.txt').read_bytes()
    assert len(data)==COUNT*28
    roots=(ROOT/'BulkData/roots.txt').read_bytes()
    assert len(roots)==28314*12
    write('KernelTable.lean','''import KernelArena
namespace Rule54.KernelArena
inductive NodeTable where
  | leaf : List Node → NodeTable
  | branch : Nat → NodeTable → NodeTable → NodeTable
def NodeTable.lookup : NodeTable → Nat → Node
  | .leaf ns, i => ns[i]?.getD default
  | .branch cut l r, i => if i < cut then l.lookup i else r.lookup (i-cut)
end Rule54.KernelArena
''')
    parts=[]
    for part,start in enumerate(range(0,COUNT,DB_PART)):
        end=min(COUNT,start+DB_PART)
        ns=[tuple(field(data[i*28+j*4:i*28+j*4+4]) for j in range(7)) for i in range(start,end)]
        name=f'KernelData.Part{part:04d}'
        write(name.replace('.','/')+'.lean','import KernelTable\nnamespace Rule54.KernelData\nopen KernelArena\ndef part'+str(part)+' : NodeTable := '+node_table(ns)+'\nend Rule54.KernelData\n')
        parts.append(('part'+str(part),end-start))
        if part%25==0: print('Generated database part',part,flush=True)
    imports=''.join(f'import KernelData.Part{i:04d}\n' for i in range(len(parts)))
    write('KernelDB.lean',imports+'namespace Rule54.KernelData\nopen KernelArena\ndef data : NodeTable := '+part_table(parts)+f'\ndef db : DB := ⟨{COUNT}, data.lookup⟩\nend Rule54.KernelData\n')
    print('Generated',COUNT,'database nodes; original certificate SHA256',hashlib.sha256(data).hexdigest(),flush=True)

def base():
    version=subprocess.check_output(['lean','--version'],text=True)
    assert '4.23.0' in version,version
    run('original-mathematical-development',[sys.executable,'tools/check.py','--jobs','2','Rule54Lean'],timeout=5400)
    compile_module('KernelCoverageProbe')
    for name in ['KernelArena','KernelBulk','KernelRanges','KernelTable']: compile_module(name)
    n=(COUNT+DB_PART-1)//DB_PART
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(compile_module,[f'KernelData.Part{i:04d}' for i in range(n)]))
    compile_module('KernelDB')

def make_node_block(block):
    start=block*(1<<BLOCK_DEPTH)
    s='import KernelDB\nimport KernelRanges\nnamespace Rule54.KernelNodes\nopen KernelArena KernelData\nset_option maxHeartbeats 0\nset_option maxRecDepth 200000\n'
    names=[]
    for j in range(1<<(BLOCK_DEPTH-LEAF_DEPTH)):
        lo=start+(j<<LEAF_DEPTH); name=f'p{block}_{j}'; names.append(name)
        proof='by decide +kernel' if lo<COUNT else f'checkBlock_outside db {LEAF_DEPTH} {lo} (by decide)'
        s+=f'private theorem {name} : checkBlock db {lo} {LEAF_DEPTH} = true := {proof}\n'
    s+=f'theorem block{block} : checkBlock db {start} {BLOCK_DEPTH} = true := '+and_proof(names)+'\n'
    s+=f'#print axioms block{block}\nend Rule54.KernelNodes\n'
    module=f'KernelNodes.Block{block:04d}'
    write(module.replace('.','/')+'.lean',s)
    compile_module(module)

def nodes(shard,shards):
    for block in range(shard,BLOCKS,shards): make_node_block(block)

def certify():
    s=''.join(f'import KernelNodes.Block{i:04d}\n' for i in range(BLOCKS))
    s+='namespace Rule54.KernelCertified\nopen KernelArena KernelData KernelNodes\nset_option maxRecDepth 200000\n'
    s+=f'theorem checked : checkBlock db 0 {DEPTH} = true := '+and_proof([f'block{i}' for i in range(BLOCKS)])+'\n'
    s+=f'theorem db_ok : allOK db = true := allOK_of_checkBlock db {DEPTH} (by decide) checked\n#print axioms db_ok\nend Rule54.KernelCertified\n'
    write('KernelCertified.lean',s); compile_module('KernelCertified')

def make_case(index,ks,rs):
    w=[field(rs[index*12+4*j:index*12+4*j+4]) for j in range(3)]
    key=ks[index]
    proof='by decide +kernel'
    if key.startswith('.writer '):
        proof='by\n  simp [BulkCases.spec, Manifest.writer, Manifest.ceilPow, Nat.log2]\n  decide +kernel'
    s='''import KernelCertified
import KernelBulk
import Rule54Lean.BulkCases
namespace Rule54Lean.KernelCases
open Rule54.KernelArena Rule54.KernelBulk
set_option maxHeartbeats 0
set_option maxRecDepth 200000
'''
    s+=f'private def w{index} : Witness := ⟨{w[0]},{w[1]},{w[2]}⟩\n'
    s+=f'private theorem ok{index} : testCase Rule54.KernelData.db w{index} (BulkCases.spec ({key})) = true := {proof}\n'
    s+=f'theorem c{index} : (BulkCases.spec ({key})).Valid := testCase_sound Rule54.KernelCertified.db_ok (w := w{index}) ok{index}\n'
    if index in [0,11228,28313]: s+=f'#print axioms c{index}\n'
    s+='end Rule54Lean.KernelCases\n'
    module=f'KernelCases.C{index:05d}'
    write(module.replace('.','/')+'.lean',s)
    compile_module(module)

def cases(shard,shards,indices=None):
    ks=keys(); rs=(ROOT/'BulkData/roots.txt').read_bytes()
    for i in (indices if indices is not None else range(shard,len(ks),shards)): make_case(i,ks,rs)

def assemble():
    ks=keys()
    imports=''.join(f'import KernelCases.C{i:05d}\n' for i in range(len(ks)))
    s=imports+'''namespace Rule54Lean.KernelCertificate
open BulkCases KernelCases
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev CertifiedKey := { k : Key // (spec k).Valid }
'''
    chunks=[]
    for chunk,start in enumerate(range(0,len(ks),128)):
        name='chunk'+str(chunk); chunks.append(name)
        s+=f'private def {name} : List CertifiedKey := [\n'
        s+=',\n'.join(f'  ⟨{ks[i]}, c{i}⟩' for i in range(start,min(len(ks),start+128)))+']\n'
    s+='private def certificates : List CertifiedKey := ['+','.join(chunks)+'].flatten\n'
    s+='''private theorem keys_eq : certificates.map (fun p => p.val) = keys := by decide +kernel
theorem all_collisions : Manifest.TransportValid ∧ Manifest.WritersValid := by
  apply cover
  intro k hk
  rw [← keys_eq] at hk
  obtain ⟨item, _, he⟩ := List.mem_map.mp hk
  exact he ▸ item.property
#print axioms all_collisions
end Rule54Lean.KernelCertificate
'''
    write('KernelAllCollisions.lean',s); compile_module('KernelAllCollisions')
    # This is the only replacement of an original proof module. Its statement
    # remains exactly the same, and the unchanged final theorem imports it.
    write('Rule54Native.lean','''import KernelAllCollisions
namespace Rule54Lean.NativeReplay
theorem all_collisions : Manifest.TransportValid ∧ Manifest.WritersValid :=
  KernelCertificate.all_collisions
#print axioms all_collisions
end Rule54Lean.NativeReplay
''')
    compile_module('Rule54Native')
    if EMIT_ONLY: return
    audit=compile_module('Rule54WeakUniversality')
    required=['simulation_iff','halting_observation','halting_iff','infinite_run','simulated_at_clock','weak_universality','rule54_simulates']
    for name in required:
        matches=re.findall(r"'Rule54Lean\.WeakUniversality\."+name+r"' depends on axioms:\s*\[([^\]]*)\]",audit,re.S)
        assert len(matches)==1,(name,audit)
        axioms={x.strip() for x in matches[0].split(',') if x.strip()}
        assert axioms<={'propext','Classical.choice','Quot.sound'},(name,axioms)
    print('FULL KERNEL-ONLY RULE 54 UNIVERSALITY VERIFIED',flush=True)
    write('KERNEL-VERIFICATION.txt',audit)

def export_source():
    global EMIT_ONLY
    assert (ROOT/'KERNEL-VERIFICATION.txt').is_file(), 'Run the complete final audit before exporting a verified package'
    EMIT_ONLY=True
    prepare()
    for block in range(BLOCKS): make_node_block(block)
    certify()
    cases(0,1)
    assemble()
    write('README-KERNEL.txt','''Kernel-only Rule 54 formalization, Lean 4.23.0.
The original theorem statements and collision manifest are retained.
Rule54Native.lean now obtains its theorem from KernelAllCollisions.lean.
The trusted compiler decisions have been replaced by kernel-checked batches.
KERNEL-VERIFICATION.txt records the final theorem's actual axiom audit.

Reproduce from sources with Lean 4.23.0 on PATH:
python3 kernel_full.py prepare
python3 kernel_full.py base
python3 kernel_full.py nodes
python3 kernel_full.py certify
python3 kernel_full.py cases
python3 kernel_full.py assemble

The old README, VERIFICATION.txt, tools/verify.py and tools/native_check.py
describe the historical native-checking pipeline. Use the commands above
for this kernel-only version. GitHub Actions can distribute the independent
node and collision checks, then assemble and audit the final theorem.
''')
    dest=ROOT.parent/'rule54-kernel-verified-source.zip'
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in ROOT.rglob('*'):
            if not p.is_file(): continue
            rel=p.relative_to(ROOT)
            if any(part.startswith('.') or part in ['__pycache__','kernel-logs','cloud-logs'] for part in rel.parts): continue
            if p.suffix in ['.olean','.ilean','.log','.tar','.zst']: continue
            z.write(p,'rule54_kernel_formalization/'+rel.as_posix())
    print('Verified source archive',dest.name,dest.stat().st_size,hashlib.sha256(dest.read_bytes()).hexdigest(),flush=True)

def pack(kind,shard=0,shards=1):
    if kind=='base': paths=list(OUT.rglob('*.olean'))
    elif kind=='nodes': paths=[OUT/f'KernelNodes/Block{i:04d}.olean' for i in range(shard,BLOCKS,shards)]
    elif kind=='certified': paths=list((OUT/'KernelNodes').glob('*.olean'))+[OUT/'KernelCertified.olean']
    elif kind=='cases': paths=[OUT/f'KernelCases/C{i:05d}.olean' for i in range(shard,len(keys()),shards)]
    else: raise ValueError(kind)
    dest=ROOT/(f'kernel-{kind}'+(f'-{shard}' if kind in ['nodes','cases'] else '')+'.tar')
    with tarfile.open(dest,'w') as t:
        for p in paths:
            assert p.is_file(),p
            t.add(p,arcname=p.relative_to(ROOT).as_posix())
    subprocess.run(['zstd','-T2','-3','--rm','-f',str(dest)],check=True)
    packed=Path(str(dest)+'.zst')
    limit={'base':250,'nodes':2,'certified':32,'cases':0.5}[kind]*1024**2
    assert packed.stat().st_size<limit,(packed,packed.stat().st_size,'artifact size limit')
    print('Artifact',packed.name,packed.stat().st_size,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['prepare','base','nodes','certify','cases','assemble','pack','export-source'])
    parser.add_argument('--shard',type=int,default=0)
    parser.add_argument('--shards',type=int,default=1)
    parser.add_argument('--indices')
    parser.add_argument('--kind')
    a=parser.parse_args()
    if a.stage=='prepare': prepare()
    elif a.stage=='base': base()
    elif a.stage=='nodes': nodes(a.shard,a.shards)
    elif a.stage=='certify': certify()
    elif a.stage=='cases': cases(a.shard,a.shards,[int(x) for x in a.indices.split(',')] if a.indices else None)
    elif a.stage=='assemble': assemble()
    elif a.stage=='pack': pack(a.kind,a.shard,a.shards)
    elif a.stage=='export-source': export_source()
